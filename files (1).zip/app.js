class NovaVideoAI {
  constructor() {
    this.scenes = [];
    this.currentVideo = null;
    this.previousVideos = [];
    this.isPlaying = false;
    this.currentSceneIndex = 0;
    this.sceneStartTime = 0;
    this.init();
  }

  init() {
    this.cacheDOMElements();
    this.attachEventListeners();
    this.loadPreviousVideos();
  }

  cacheDOMElements() {
    // Input elements
    this.promptInput = document.getElementById('promptInput');
    this.sceneSlider = document.getElementById('sceneSlider');
    this.sceneValue = document.getElementById('sceneValue');
    this.fpsSlider = document.getElementById('fpsSlider');
    this.fpsValue = document.getElementById('fpsValue');

    // Buttons
    this.generateButton = document.getElementById('generateButton');
    this.expandButton = document.getElementById('expandButton');
    this.playBtn = document.getElementById('playBtn');
    this.pauseBtn = document.getElementById('pauseBtn');

    // Containers
    this.scenesContainer = document.getElementById('scenesContainer');
    this.scenesPreviewContainer = document.getElementById('scenesPreviewContainer');
    this.previousVideos_el = document.getElementById('previousVideos');

    // States
    this.videoPreview = document.getElementById('videoPreview');
    this.emptyState = document.getElementById('emptyState');
    this.loadingState = document.getElementById('loadingState');
    this.errorState = document.getElementById('errorState');
    this.errorMessage = document.getElementById('errorMessage');

    // Preview elements
    this.videoTitle = document.getElementById('videoTitle');
    this.previewSceneCount = document.getElementById('previewSceneCount');
    this.previewFps = document.getElementById('previewFps');
    this.progressFill = document.getElementById('progressFill');
    this.timeDisplay = document.getElementById('timeDisplay');
    this.progressBar = document.querySelector('.progress-bar');
  }

  attachEventListeners() {
    this.sceneSlider.addEventListener('input', (e) => {
      this.sceneValue.textContent = e.target.value;
    });

    this.fpsSlider.addEventListener('input', (e) => {
      this.fpsValue.textContent = e.target.value;
      if (this.currentVideo) {
        this.updatePreview();
      }
    });

    this.expandButton.addEventListener('click', () => this.expandScenes());
    this.generateButton.addEventListener('click', () => this.generateVideo());
    this.playBtn.addEventListener('click', () => this.play());
    this.pauseBtn.addEventListener('click', () => this.pause());
    this.progressBar.addEventListener('click', (e) => this.seek(e));
  }

  async expandScenes() {
    const prompt = this.promptInput.value.trim();
    const sceneCount = parseInt(this.sceneSlider.value);

    if (!prompt) {
      this.showError('Please enter a video concept first');
      return;
    }

    try {
      this.expandButton.disabled = true;
      this.showError('');

      const response = await fetch('/api/generate-script', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          prompt: prompt,
          sceneCount: sceneCount
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to expand scenes');
      }

      const data = await response.json();
      this.scenes = data.scenes;
      this.renderSceneInputs();
      this.showError('');
    } catch (error) {
      console.error('Error expanding scenes:', error);
      this.showError(error.message);
    } finally {
      this.expandButton.disabled = false;
    }
  }

  renderSceneInputs() {
    this.scenesContainer.innerHTML = '';

    if (this.scenes.length === 0) {
      this.scenesContainer.innerHTML = '<p class="placeholder-text">Scenes will appear here after AI Expand</p>';
      return;
    }

    this.scenes.forEach((scene, index) => {
      const sceneGroup = document.createElement('div');
      sceneGroup.className = 'scene-input-group';

      const sceneNumber = document.createElement('div');
      sceneNumber.className = 'scene-number';
      sceneNumber.textContent = scene.scene;

      const sceneInput = document.createElement('textarea');
      sceneInput.className = 'scene-input';
      sceneInput.value = scene.text;
      sceneInput.addEventListener('change', (e) => {
        this.scenes[index].text = e.target.value;
        this.scenes[index].imagePrompt = e.target.value;
      });

      sceneGroup.appendChild(sceneNumber);
      sceneGroup.appendChild(sceneInput);
      this.scenesContainer.appendChild(sceneGroup);
    });
  }

  async generateVideo() {
    if (this.scenes.length === 0) {
      this.showError('Please expand scenes first');
      return;
    }

    try {
      this.generateButton.disabled = true;
      this.loadingState.classList.remove('hidden');
      this.showError('');

      const result = {
        prompt: this.promptInput.value,
        sceneCount: this.scenes.length,
        fps: parseInt(this.fpsSlider.value),
        scenes: this.scenes,
        timestamp: new Date().toISOString()
      };

      this.currentVideo = result;
      this.previousVideos.unshift(result);
      this.savePreviousVideos();
      this.updatePreview();
      this.renderPreviousVideos();

      setTimeout(() => {
        this.loadingState.classList.add('hidden');
      }, 1500);
    } catch (error) {
      console.error('Error generating video:', error);
      this.showError(error.message);
      this.loadingState.classList.add('hidden');
    } finally {
      this.generateButton.disabled = false;
    }
  }

  updatePreview() {
    if (!this.currentVideo) return;

    this.videoTitle.textContent = this.currentVideo.prompt.substring(0, 50) + '...';
    this.previewSceneCount.textContent = this.currentVideo.scenes.length;
    this.previewFps.textContent = this.currentVideo.fps;

    this.emptyState.classList.add('hidden');
    this.videoPreview.classList.remove('hidden');

    this.renderScenePreview();
    this.resetPlayback();
  }

  renderScenePreview() {
    this.scenesPreviewContainer.innerHTML = '';

    this.currentVideo.scenes.forEach((scene, index) => {
      const sceneItem = document.createElement('div');
      sceneItem.className = 'scene-preview-item';

      const sceneImage = document.createElement('div');
      sceneImage.className = 'scene-preview-image';
      sceneImage.textContent = '🎬';

      const sceneText = document.createElement('div');
      sceneText.className = 'scene-preview-text';
      sceneText.textContent = scene.text;

      const sceneNumber = document.createElement('div');
      sceneNumber.className = 'scene-preview-number';
      sceneNumber.textContent = scene.scene;

      sceneItem.appendChild(sceneImage);
      sceneItem.appendChild(sceneText);
      sceneItem.appendChild(sceneNumber);

      sceneItem.addEventListener('click', () => {
        this.currentSceneIndex = index;
        this.sceneStartTime = Date.now();
      });

      this.scenesPreviewContainer.appendChild(sceneItem);
    });
  }

  play() {
    if (this.currentVideo) {
      this.isPlaying = true;
      this.sceneStartTime = Date.now();
      this.playBtn.classList.add('active');
      this.pauseBtn.classList.remove('active');
      this.animatePlayback();
    }
  }

  pause() {
    this.isPlaying = false;
    this.playBtn.classList.remove('active');
    this.pauseBtn.classList.add('active');
  }

  animatePlayback() {
    if (!this.isPlaying || !this.currentVideo) return;

    const fps = this.currentVideo.fps;
    const sceneDuration = (1000 / fps) * 30; // Roughly 30 frames per scene

    const elapsedTime = Date.now() - this.sceneStartTime;
    const totalDuration = this.currentVideo.scenes.length * sceneDuration;

    const progress = (elapsedTime % totalDuration) / totalDuration;
    this.progressFill.style.width = (progress * 100) + '%';

    const minutes = Math.floor((elapsedTime / 1000) / 60);
    const seconds = Math.floor((elapsedTime / 1000) % 60);
    const totalMinutes = Math.floor((totalDuration / 1000) / 60);
    const totalSeconds = Math.floor((totalDuration / 1000) % 60);

    this.timeDisplay.textContent = `${minutes}:${seconds.toString().padStart(2, '0')} / ${totalMinutes}:${totalSeconds.toString().padStart(2, '0')}`;

    if (elapsedTime >= totalDuration) {
      this.currentSceneIndex = 0;
      this.sceneStartTime = Date.now();
    }

    requestAnimationFrame(() => this.animatePlayback());
  }

  seek(e) {
    if (!this.currentVideo) return;

    const rect = this.progressBar.getBoundingClientRect();
    const percent = (e.clientX - rect.left) / rect.width;
    const fps = this.currentVideo.fps;
    const sceneDuration = (1000 / fps) * 30;
    const totalDuration = this.currentVideo.scenes.length * sceneDuration;

    this.sceneStartTime = Date.now() - (percent * totalDuration);
  }

  resetPlayback() {
    this.isPlaying = false;
    this.currentSceneIndex = 0;
    this.sceneStartTime = 0;
    this.playBtn.classList.add('active');
    this.pauseBtn.classList.remove('active');
    this.progressFill.style.width = '0%';
    this.timeDisplay.textContent = '0:00 / 0:00';
  }

  renderPreviousVideos() {
    if (this.previousVideos.length === 0) {
      this.previousVideos_el.innerHTML = '<p class="placeholder-text">No videos generated yet</p>';
      return;
    }

    this.previousVideos_el.innerHTML = '';

    this.previousVideos.slice(0, 10).forEach((video, index) => {
      const item = document.createElement('div');
      item.className = 'previous-video-item';

      const date = new Date(video.timestamp);
      const timeStr = date.toLocaleTimeString();

      const text = document.createElement('div');
      text.className = 'previous-video-text';
      text.textContent = video.prompt.substring(0, 40) + '...';
      text.title = video.prompt;

      const time = document.createElement('div');
      time.className = 'previous-video-time';
      time.textContent = timeStr;

      const deleteBtn = document.createElement('button');
      deleteBtn.className = 'previous-video-delete';
      deleteBtn.innerHTML = '✕';
      deleteBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        this.previousVideos.splice(index, 1);
        this.savePreviousVideos();
        this.renderPreviousVideos();
      });

      item.appendChild(text);
      item.appendChild(time);
      item.appendChild(deleteBtn);

      item.addEventListener('click', () => {
        this.currentVideo = video;
        this.updatePreview();
      });

      this.previousVideos_el.appendChild(item);
    });
  }

  savePreviousVideos() {
    localStorage.setItem('novavideos', JSON.stringify(this.previousVideos));
  }

  loadPreviousVideos() {
    const saved = localStorage.getItem('novavideos');
    if (saved) {
      try {
        this.previousVideos = JSON.parse(saved);
        this.renderPreviousVideos();
      } catch (e) {
        console.error('Error loading previous videos:', e);
      }
    }
  }

  showError(message) {
    if (message) {
      this.errorMessage.textContent = message;
      this.errorState.classList.remove('hidden');
    } else {
      this.errorState.classList.add('hidden');
    }
  }
}

document.addEventListener('DOMContentLoaded', () => {
  new NovaVideoAI();
});